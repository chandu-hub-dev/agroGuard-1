
import React from 'react';
import { Language, LANGUAGES, AppState } from '../types';

interface HeaderProps {
  currentLanguage: Language;
  onLanguageChange: (lang: Language) => void;
  appState: AppState;
  setAppState: (state: AppState) => void;
  t: any;
}

const Header: React.FC<HeaderProps> = ({ currentLanguage, onLanguageChange, appState, setAppState, t }) => {
  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo Section */}
          <div className="flex items-center space-x-3 cursor-pointer group" onClick={() => setAppState(AppState.IDLE)}>
            <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-200 group-hover:scale-105 transition-transform">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
              </svg>
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900 tracking-tight leading-none">AgroGuard AI</h1>
              <p className="text-[10px] text-emerald-600 font-bold uppercase tracking-[0.2em] hidden sm:block mt-1">{t.app_subtitle}</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-2">
            <button 
              onClick={() => setAppState(AppState.IDLE)}
              className={`px-5 py-2 rounded-xl text-sm font-bold transition-all ${appState !== AppState.ENCYCLOPEDIA ? 'bg-emerald-50 text-emerald-700 shadow-sm border border-emerald-100' : 'text-gray-500 hover:text-emerald-600 hover:bg-gray-50'}`}
            >
              {t.nav_home}
            </button>
            <button 
              onClick={() => setAppState(AppState.ENCYCLOPEDIA)}
              className={`px-5 py-2 rounded-xl text-sm font-bold transition-all ${appState === AppState.ENCYCLOPEDIA ? 'bg-emerald-50 text-emerald-700 shadow-sm border border-emerald-100' : 'text-gray-500 hover:text-emerald-600 hover:bg-gray-50'}`}
            >
              {t.nav_encyclopedia}
            </button>
          </nav>

          {/* Language Selector */}
          <div className="flex items-center">
            <div className="relative group">
              <select 
                value={currentLanguage}
                onChange={(e) => onLanguageChange(e.target.value as Language)}
                className="appearance-none bg-gray-50 border border-gray-200 text-gray-700 font-medium text-sm rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 block pl-4 pr-10 py-2.5 outline-none transition-all cursor-pointer hover:bg-white"
              >
                {LANGUAGES.map((lang) => (
                  <option key={lang.code} value={lang.code}>
                    {lang.native}
                  </option>
                ))}
              </select>
              <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-gray-400">
                <svg className="h-4 w-4 fill-current" viewBox="0 0 20 20">
                  <path d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" />
                </svg>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;

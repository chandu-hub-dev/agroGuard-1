
import React, { useState, useRef } from 'react';
import { Language, PlantAnalysis, EncyclopediaEntry, AppState } from '../types';
import { generateSpeech, decodeBase64, decodeAudioData } from '../services/geminiService';

interface FloatingAssistantProps {
  currentLanguage: Language;
  t: any;
  appState: AppState;
  analysisData: PlantAnalysis | null;
  encyclopediaData: EncyclopediaEntry | null;
}

const FloatingAssistant: React.FC<FloatingAssistantProps> = ({ currentLanguage, t, appState, analysisData, encyclopediaData }) => {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);

  const initAudioContext = () => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    }
    return audioContextRef.current;
  };

  const stopSpeaking = () => {
    if (sourceNodeRef.current) {
      try {
        sourceNodeRef.current.stop();
      } catch (e) {
        // Node might have already finished playing or hasn't started
      }
      sourceNodeRef.current = null;
    }
    setIsSpeaking(false);
  };

  const handleAssistantClick = async () => {
    if (isSpeaking) {
      stopSpeaking();
      return;
    }

    const audioCtx = initAudioContext();
    if (audioCtx.state === 'suspended') {
      await audioCtx.resume();
    }

    setIsLoading(true);
    try {
      let textToSpeak = '';

      if (appState === AppState.RESULT && analysisData) {
        textToSpeak = `
          ${t.assistant_result_prefix} 
          ${analysisData.plantName}. 
          ${analysisData.isHealthy ? t.result_status_healthy : t.result_status_diseased}. 
          ${!analysisData.isHealthy ? `${t.result_symptoms}: ${analysisData.symptoms.join(', ')}.` : ''}
          ${t.result_recommendations}: ${analysisData.recommendations.join('. ')}.
        `;
      } else if (appState === AppState.ENCYCLOPEDIA && encyclopediaData) {
        textToSpeak = `
          ${t.assistant_encyclopedia_prefix} 
          ${encyclopediaData.title}.
          ${encyclopediaData.description}.
        `;
      } else {
        textToSpeak = t.assistant_idle_prompt;
      }

      const base64Audio = await generateSpeech(textToSpeak, currentLanguage);
      if (base64Audio) {
        const decoded = decodeBase64(base64Audio);
        const audioBuffer = await decodeAudioData(decoded, audioCtx, 24000, 1);
        
        const source = audioCtx.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(audioCtx.destination);
        source.onended = () => setIsSpeaking(false);
        
        sourceNodeRef.current = source;
        setIsSpeaking(true);
        source.start(0);
      }
    } catch (err) {
      console.error("Assistant failed", err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-[60] flex flex-col items-end space-y-2">
      {isSpeaking && (
        <div className="bg-white px-4 py-2 rounded-2xl shadow-xl border border-emerald-100 mb-2 animate-in slide-in-from-bottom-2 duration-300 flex items-center space-x-2">
          <div className="flex space-x-1 items-end h-4">
            <div className="w-1 bg-emerald-400 animate-[bounce_1s_infinite_0ms]" style={{height: '60%'}}></div>
            <div className="w-1 bg-emerald-500 animate-[bounce_1s_infinite_200ms]" style={{height: '100%'}}></div>
            <div className="w-1 bg-emerald-600 animate-[bounce_1s_infinite_400ms]" style={{height: '80%'}}></div>
          </div>
          <span className="text-xs font-bold text-emerald-800 uppercase tracking-widest">{t.assistant_label}</span>
        </div>
      )}
      
      <button 
        onClick={handleAssistantClick}
        disabled={isLoading}
        aria-label="Toggle AI Assistant"
        className={`group relative w-16 h-16 rounded-full shadow-2xl transition-all active:scale-95 flex items-center justify-center
          ${isSpeaking ? 'bg-emerald-600 scale-110' : 'bg-white hover:bg-emerald-50'}
          ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}
        `}
      >
        {!isSpeaking && !isLoading && (
          <div className="absolute inset-0 rounded-full border-2 border-emerald-500 animate-ping opacity-20"></div>
        )}

        {isLoading ? (
          <div className="animate-spin h-8 w-8 text-emerald-600 border-4 border-emerald-100 border-t-emerald-600 rounded-full"></div>
        ) : isSpeaking ? (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        ) : (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-emerald-600 group-hover:scale-110 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
             <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
          </svg>
        )}
      </button>
    </div>
  );
};

export default FloatingAssistant;

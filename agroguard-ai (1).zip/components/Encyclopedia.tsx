
import React, { useState } from 'react';
import { EncyclopediaEntry, Language } from '../types';
import { fetchEncyclopediaEntry } from '../services/geminiService';

interface EncyclopediaProps {
  currentLanguage: Language;
  t: any;
  initialQuery?: string;
  setEncyclopediaContent: (data: EncyclopediaEntry | null) => void;
  encyclopediaContent: EncyclopediaEntry | null;
}

const Encyclopedia: React.FC<EncyclopediaProps> = ({ currentLanguage, t, initialQuery = '', setEncyclopediaContent, encyclopediaContent }) => {
  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [isLoading, setIsLoading] = useState(false);

  const handleSearch = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!searchQuery.trim()) return;

    setIsLoading(true);
    try {
      const result = await fetchEncyclopediaEntry(searchQuery, currentLanguage);
      setEncyclopediaContent(result);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const popularSearches = ['Late Blight', 'Leaf Rust', 'Aphids', 'Nitrogen Deficiency', 'Powdery Mildew'];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="bg-emerald-900 rounded-3xl p-8 text-white shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-40 w-40" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
          </svg>
        </div>
        
        <div className="relative z-10">
          <h2 className="text-3xl font-extrabold mb-2">{t.encyclopedia_title}</h2>
          <p className="text-emerald-100 mb-6 max-w-lg">Access verified agricultural knowledge and treatment protocols for any crop condition.</p>
          
          <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-3">
            <input 
              type="text" 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.encyclopedia_search_placeholder}
              className="flex-grow bg-white/10 border border-white/20 rounded-xl px-5 py-3 text-white placeholder:text-emerald-200 outline-none focus:ring-2 focus:ring-emerald-400 backdrop-blur-md"
            />
            <button 
              type="submit"
              disabled={isLoading}
              className="bg-emerald-500 hover:bg-emerald-400 text-white font-bold px-8 py-3 rounded-xl transition-all shadow-lg active:scale-95 disabled:opacity-50"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
              ) : (
                'Search'
              )}
            </button>
          </form>

          <div className="mt-6 flex flex-wrap gap-2 items-center">
            <span className="text-xs font-bold text-emerald-300 uppercase tracking-widest mr-2">{t.encyclopedia_popular}:</span>
            {popularSearches.map(s => (
              <button 
                key={s} 
                onClick={() => { setSearchQuery(s); handleSearch(); }}
                className="text-xs bg-white/10 hover:bg-white/20 border border-white/10 px-3 py-1 rounded-full transition-colors"
              >
                {s}
              </button>
            ))}
          </div>
        </div>
      </div>

      {isLoading && !encyclopediaContent && (
        <div className="flex flex-col items-center justify-center py-20 animate-pulse">
           <div className="w-12 h-12 border-4 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin mb-4"></div>
           <p className="text-gray-400 font-medium">{t.encyclopedia_loading}</p>
        </div>
      )}

      {encyclopediaContent && (
        <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-xl animate-in slide-in-from-bottom-8 duration-500">
          <div className="flex flex-col md:flex-row md:items-end justify-between border-b border-gray-100 pb-6 mb-8">
            <div>
              <span className="text-xs font-bold text-emerald-600 uppercase tracking-widest mb-1 block">{encyclopediaContent.category}</span>
              <h3 className="text-4xl font-extrabold text-gray-900">{encyclopediaContent.title}</h3>
              <p className="text-gray-400 italic font-medium">{encyclopediaContent.scientificName}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            <div className="lg:col-span-2 space-y-8">
              <section>
                <h4 className="text-lg font-bold text-gray-800 mb-3 flex items-center">
                  <div className="w-8 h-8 bg-emerald-50 text-emerald-600 rounded-lg flex items-center justify-center mr-3">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                      <path d="M11 3a1 1 0 10-2 0v1a1 1 0 102 0V3zM15.657 5.757a1 1 0 00-1.414-1.414l-.707.707a1 1 0 001.414 1.414l.707-.707zM18 10a1 1 0 01-1 1h-1a1 1 0 110-2h1a1 1 0 011 1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zM5 10a1 1 0 01-1 1H3a1 1 0 110-2h1a1 1 0 011 1zM8 16v-1h4v1a2 2 0 11-4 0zM12 14c.015-.34.208-.646.477-.859a4 4 0 10-4.954 0c.27.213.462.519.477.859h4z" />
                    </svg>
                  </div>
                  Understanding & Biology
                </h4>
                <p className="text-gray-600 leading-relaxed bg-gray-50 p-6 rounded-2xl">
                  {encyclopediaContent.description}
                </p>
                <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3">
                  {encyclopediaContent.causes.map((c, i) => (
                    <div key={i} className="flex items-center text-sm text-gray-500 bg-white border border-gray-100 p-3 rounded-xl shadow-sm">
                      <div className="w-2 h-2 bg-emerald-400 rounded-full mr-3"></div>
                      {c}
                    </div>
                  ))}
                </div>
              </section>

              <section>
                <h4 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
                  <div className="w-8 h-8 bg-emerald-50 text-emerald-600 rounded-lg flex items-center justify-center mr-3">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M12.395 2.553a1 1 0 00-1.4503-.385l-7 3.5a1 1 0 00-.547.894v7.942a1 1 0 001.4503.385l7-3.5a1 1 0 00.547-.894V3.447a1 1 0 00-.453-.894zM4.5 6.723l5-2.5v5.554l-5 2.5V6.723zm7 5.554l-5 2.5v-5.554l5-2.5v5.554z" clipRule="evenodd" />
                    </svg>
                  </div>
                  Refined Treatment Protocols
                </h4>
                <div className="space-y-3">
                  {encyclopediaContent.detailedTreatments.map((t, i) => (
                    <div key={i} className="flex items-start bg-white p-4 rounded-2xl border border-gray-100 shadow-sm group hover:border-emerald-200 transition-colors">
                      <div className="font-bold text-emerald-600 mr-4 mt-0.5">{i+1}.</div>
                      <p className="text-gray-700 text-sm leading-relaxed">{t}</p>
                    </div>
                  ))}
                </div>
              </section>
            </div>

            <div className="space-y-6">
              <section className="bg-emerald-50 rounded-3xl p-6 border border-emerald-100">
                <h4 className="text-emerald-900 font-bold mb-4 flex items-center text-sm uppercase tracking-wider">
                   <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 4.946-2.597 9.29-6.518 11.771a1.307 1.307 0 01-1.478 0C6.01 16.29 3.413 11.946 3.413 7c0-.682.057-1.351.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  Prevention Measures
                </h4>
                <ul className="space-y-3">
                  {encyclopediaContent.preventionMeasures.map((pm, i) => (
                    <li key={i} className="flex items-start text-xs text-emerald-800 leading-relaxed">
                      <svg className="h-4 w-4 text-emerald-500 mr-2 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"></path></svg>
                      {pm}
                    </li>
                  ))}
                </ul>
              </section>

              <section className="bg-gray-900 rounded-3xl p-6 text-white">
                <h4 className="text-gray-300 font-bold mb-4 flex items-center text-sm uppercase tracking-wider">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" />
                  </svg>
                  Cultural Practices
                </h4>
                <div className="space-y-3">
                  {encyclopediaContent.culturalPractices.map((cp, i) => (
                    <div key={i} className="text-xs text-gray-400 bg-white/5 p-3 rounded-xl border border-white/10">
                      {cp}
                    </div>
                  ))}
                </div>
              </section>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Encyclopedia;


import React from 'react';
import { PlantAnalysis } from '../types';

interface AnalysisResultProps {
  data: PlantAnalysis;
  imageUrl: string;
  onReset: () => void;
  onLearnMore: (query: string) => void;
  t: any;
}

const AnalysisResult: React.FC<AnalysisResultProps> = ({ data, imageUrl, onReset, onLearnMore, t }) => {
  const urgencyColors = {
    low: 'bg-sky-50 text-sky-700 border-sky-100',
    medium: 'bg-amber-50 text-amber-700 border-amber-100',
    high: 'bg-rose-50 text-rose-700 border-rose-100',
  };

  const confidencePercentage = Math.round(data.confidence * 100);

  return (
    <div className="space-y-8 pb-16 animate-in fade-in slide-in-from-bottom-6 duration-700">
      <div className="bg-white rounded-[3rem] overflow-hidden shadow-2xl border border-slate-100 flex flex-col lg:flex-row">
        {/* Image Section */}
        <div className="lg:w-2/5 relative h-96 lg:h-auto overflow-hidden group">
          <img 
            src={imageUrl} 
            alt="Analyzed leaf" 
            className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
          
          <div className="absolute bottom-8 left-8 right-8">
            <div className={`inline-flex items-center px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] shadow-2xl backdrop-blur-xl border ${data.isHealthy ? 'bg-emerald-500/90 text-white border-emerald-400' : 'bg-rose-500/90 text-white border-rose-400'}`}>
              <div className={`w-2 h-2 rounded-full mr-2 animate-pulse ${data.isHealthy ? 'bg-white' : 'bg-white'}`}></div>
              {data.isHealthy ? t.result_status_healthy : t.result_status_diseased}
            </div>
          </div>
        </div>

        {/* Info Section */}
        <div className="p-10 lg:p-14 lg:w-3/5 space-y-10 bg-white">
          <div className="flex justify-between items-start">
            <div className="space-y-2">
              <span className="text-[10px] font-black text-emerald-600 uppercase tracking-[0.4em] block">{t.result_identification}</span>
              <h2 className="text-4xl lg:text-5xl font-black text-slate-900 leading-tight">{data.plantName}</h2>
              {!data.isHealthy && (
                <div className="inline-block px-4 py-2 bg-rose-50 rounded-2xl">
                  <p className="text-xl font-bold text-rose-600">{data.diseaseName}</p>
                </div>
              )}
            </div>
            
            <div className="flex flex-col items-center shrink-0">
               <div className="relative w-20 h-20">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                    <circle cx="18" cy="18" r="16" fill="none" className="stroke-slate-100" strokeWidth="3"></circle>
                    <circle cx="18" cy="18" r="16" fill="none" className="stroke-emerald-500" strokeWidth="3" strokeDasharray={`${confidencePercentage}, 100`} strokeLinecap="round"></circle>
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-xs font-black text-slate-900">{confidencePercentage}%</span>
                  </div>
               </div>
               <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest mt-2">{t.result_match}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <div className="space-y-5">
              <h4 className="text-xs font-black text-slate-400 uppercase tracking-[0.3em] flex items-center">
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full mr-2"></span>
                {t.result_symptoms}
              </h4>
              <div className="space-y-3">
                {data.symptoms.map((s, i) => (
                  <div key={i} className="flex items-center text-slate-600 bg-slate-50 p-4 rounded-2xl border border-slate-100/50">
                    <span className="text-sm font-bold leading-tight">{s}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-5">
              <h4 className="text-xs font-black text-slate-400 uppercase tracking-[0.3em] flex items-center">
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full mr-2"></span>
                {t.result_recommendations}
              </h4>
              <div className="space-y-3">
                {data.recommendations.map((r, i) => (
                  <div key={i} className="bg-emerald-50/50 p-5 rounded-[1.5rem] border border-emerald-100/50 text-sm text-emerald-900 font-bold leading-relaxed">
                    {r}
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="pt-10 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-8">
            <div className={`px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] border shadow-sm ${urgencyColors[data.urgency]}`}>
              {t.result_urgency}: <span className="underline decoration-2 underline-offset-4">{data.urgency}</span>
            </div>

            <div className="flex items-center space-x-4 w-full sm:w-auto">
              <button 
                onClick={() => onLearnMore(data.diseaseName || data.plantName)}
                className="flex-1 sm:flex-none px-8 py-4 bg-slate-900 text-white rounded-[1.25rem] text-sm font-black hover:bg-slate-800 transition-all active:scale-95 shadow-xl shadow-slate-200"
              >
                {t.btn_learn_more}
              </button>
              
              <button 
                onClick={onReset}
                className="px-8 py-4 bg-white text-slate-500 border border-slate-200 rounded-[1.25rem] text-sm font-black hover:bg-slate-50 transition-all active:scale-95"
              >
                {t.btn_new_analysis}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalysisResult;

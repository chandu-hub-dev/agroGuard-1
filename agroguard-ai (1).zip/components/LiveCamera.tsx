
import React, { useRef, useEffect, useState } from 'react';

interface LiveCameraProps {
  onCapture: (base64: string) => void;
  onCancel: () => void;
}

const LiveCamera: React.FC<LiveCameraProps> = ({ onCapture, onCancel }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    let currentStream: MediaStream | null = null;

    async function startCamera() {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setError("Camera API is not supported in this environment (requires HTTPS).");
        return;
      }

      // Progressive fallbacks for camera access
      const constraintOptions: MediaStreamConstraints[] = [
        { video: { facingMode: { ideal: 'environment' } } },
        { video: { facingMode: 'user' } },
        { video: true }
      ];

      let lastError: any = null;

      for (const constraints of constraintOptions) {
        try {
          const newStream = await navigator.mediaDevices.getUserMedia(constraints);
          currentStream = newStream;
          
          if (videoRef.current) {
            videoRef.current.srcObject = newStream;
            videoRef.current.onloadeddata = () => {
              setIsReady(true);
              videoRef.current?.play().catch(e => console.warn("Autoplay was prevented", e));
            };
          }
          setStream(newStream);
          return;
        } catch (err: any) {
          lastError = err;
          console.warn("Constraint failed:", constraints, err);
        }
      }

      if (lastError) {
        if (lastError.name === 'NotAllowedError' || lastError.name === 'PermissionDeniedError') {
          setError("Camera permission denied. Please allow camera access in your browser settings.");
        } else if (lastError.name === 'NotFoundError' || lastError.name === 'DevicesNotFoundError') {
          setError("No camera found on this device.");
        } else {
          setError(`Camera error: ${lastError.message || "Failed to start"}`);
        }
      }
    }

    startCamera();

    return () => {
      if (currentStream) {
        currentStream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const captureFrame = () => {
    if (videoRef.current && canvasRef.current && isReady) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');

      if (context) {
        const width = video.videoWidth || 640;
        const height = video.videoHeight || 480;
        canvas.width = width;
        canvas.height = height;
        context.drawImage(video, 0, 0, width, height);
        const base64 = canvas.toDataURL('image/jpeg', 0.9);
        onCapture(base64);
      }
    }
  };

  if (error) {
    return (
      <div className="p-8 text-center bg-white rounded-[2rem] border border-red-100 shadow-2xl max-w-md mx-auto">
        <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-6 text-red-500">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
        </div>
        <h3 className="text-xl font-bold text-gray-900 mb-2">Camera Error</h3>
        <p className="text-gray-500 text-sm mb-6">{error}</p>
        <button onClick={onCancel} className="px-6 py-2 bg-gray-100 text-gray-700 rounded-xl font-bold">Go Back</button>
      </div>
    );
  }

  return (
    <div className="relative w-full aspect-square md:aspect-video bg-black rounded-[2.5rem] overflow-hidden shadow-2xl border-4 border-white">
      <video ref={videoRef} autoPlay playsInline muted className={`w-full h-full object-cover transition-opacity duration-500 ${isReady ? 'opacity-100' : 'opacity-0'}`} />
      <canvas ref={canvasRef} className="hidden" />

      {isReady && (
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
          <div className="w-64 h-64 border-2 border-white/20 border-dashed rounded-3xl"></div>
        </div>
      )}

      <div className="absolute bottom-8 left-0 right-0 flex justify-center items-center space-x-8 px-6">
        <button onClick={onCancel} className="w-12 h-12 rounded-full bg-black/50 text-white flex items-center justify-center backdrop-blur-md border border-white/10">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
        </button>

        <button onClick={captureFrame} disabled={!isReady} className="w-20 h-20 rounded-full bg-white flex items-center justify-center shadow-2xl active:scale-90 disabled:opacity-50">
          <div className="w-16 h-16 rounded-full border-4 border-emerald-600 flex items-center justify-center">
            <div className="w-12 h-12 rounded-full bg-emerald-600"></div>
          </div>
        </button>

        <div className="w-12 h-12"></div>
      </div>

      {!isReady && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-900">
          <div className="w-12 h-12 border-4 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin"></div>
          <p className="mt-4 text-emerald-500 font-bold text-xs tracking-widest uppercase">Starting Camera...</p>
        </div>
      )}
    </div>
  );
};

export default LiveCamera;

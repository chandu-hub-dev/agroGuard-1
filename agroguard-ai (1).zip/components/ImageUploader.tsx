
import React, { useRef } from 'react';

interface ImageUploaderProps {
  onImageSelect: (base64: string) => void;
  onCameraRequest: () => void;
  disabled?: boolean;
  t: any;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({ onImageSelect, onCameraRequest, disabled, t }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onImageSelect(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerGallery = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="w-full space-y-4">
      <input
        type="file"
        accept="image/*"
        className="hidden"
        ref={fileInputRef}
        onChange={handleFileChange}
      />
      
      {/* Primary Action: Camera */}
      <button 
        onClick={disabled ? undefined : onCameraRequest}
        className={`w-full relative group border-2 border-dashed rounded-3xl p-10 flex flex-col items-center justify-center transition-all 
          ${disabled ? 'opacity-50 cursor-not-allowed bg-gray-50 border-gray-200' : 'bg-emerald-600 border-emerald-500 hover:bg-emerald-700 hover:border-emerald-600 shadow-xl shadow-emerald-200'}
        `}
      >
        <div className="w-20 h-20 bg-emerald-500 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
          </svg>
        </div>
        <h3 className="text-2xl font-bold text-white mb-2">{t.btn_open_camera}</h3>
        <p className="text-emerald-100 text-center max-w-xs">
          {t.camera_description}
        </p>
      </button>

      {/* Secondary Action: Upload */}
      <div 
        onClick={disabled ? undefined : triggerGallery}
        className={`w-full py-6 flex items-center justify-center space-x-3 rounded-2xl border-2 border-gray-100 bg-white hover:bg-gray-50 cursor-pointer transition-all active:scale-[0.98]
          ${disabled ? 'opacity-50 cursor-not-allowed' : ''}
        `}
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
        </svg>
        <span className="font-semibold text-gray-600">{t.btn_upload_gallery}</span>
      </div>
    </div>
  );
};

export default ImageUploader;

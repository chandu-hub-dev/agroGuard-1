
import React, { useState, useEffect } from 'react';

interface LoadingStateProps {
  t: any;
}

const LoadingState: React.FC<LoadingStateProps> = ({ t }) => {
  const [milestoneIndex, setMilestoneIndex] = useState(0);
  
  const milestones = [
    "Optimizing image quality...",
    "Scanning leaf texture...",
    "Comparing with plant datasets...",
    "Finalizing diagnosis..."
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setMilestoneIndex((prev) => (prev < milestones.length - 1 ? prev + 1 : prev));
    }, 1200);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center py-20 animate-in fade-in duration-500">
      <div className="relative mb-10">
        <div className="w-28 h-28 border-4 border-emerald-50 rounded-full"></div>
        <div className="absolute top-0 left-0 w-28 h-28 border-t-4 border-emerald-600 rounded-full animate-spin"></div>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-16 h-16 bg-emerald-50 rounded-2xl flex items-center justify-center animate-pulse">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
        </div>
      </div>
      
      <div className="text-center space-y-2">
        <h3 className="text-2xl font-black text-slate-900">{t.loading_title}</h3>
        <p className="text-emerald-600 font-bold text-sm tracking-widest uppercase animate-pulse">
          {milestones[milestoneIndex]}
        </p>
        <p className="text-slate-400 text-sm max-w-xs mx-auto pt-2">
          {t.loading_description}
        </p>
      </div>

      <div className="mt-12 flex space-x-3">
        {[0, 1, 2].map((i) => (
          <div 
            key={i} 
            className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-bounce" 
            style={{ animationDelay: `${i * 0.15}s` }}
          ></div>
        ))}
      </div>
    </div>
  );
};

export default LoadingState;

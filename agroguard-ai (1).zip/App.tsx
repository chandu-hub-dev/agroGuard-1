
import React, { useState, useCallback, useMemo } from 'react';
import Header from './components/Header';
import ImageUploader from './components/ImageUploader';
import LiveCamera from './components/LiveCamera';
import AnalysisResult from './components/AnalysisResult';
import Encyclopedia from './components/Encyclopedia';
import LoadingState from './components/LoadingState';
import FloatingAssistant from './components/FloatingAssistant';
import { PlantAnalysis, AppState, Language, TRANSLATIONS, EncyclopediaEntry } from './types';
import { analyzePlantImage, fetchEncyclopediaEntry } from './services/geminiService';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<PlantAnalysis | null>(null);
  const [encyclopediaContent, setEncyclopediaContent] = useState<EncyclopediaEntry | null>(null);
  const [initialEncyclopediaQuery, setInitialEncyclopediaQuery] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [currentLanguage, setCurrentLanguage] = useState<Language>('en');

  const t = useMemo(() => TRANSLATIONS[currentLanguage], [currentLanguage]);

  const performAnalysis = async (base64: string, lang: Language) => {
    setAppState(AppState.ANALYZING);
    setError(null);
    try {
      const result = await analyzePlantImage(base64, lang);
      setAnalysis(result);
      setAppState(AppState.RESULT);
    } catch (err: any) {
      console.error("APP ANALYSIS ERROR:", err);
      // Use the specific error message from service if available, otherwise fallback
      const errorMsg = err.message || TRANSLATIONS[lang].err_description;
      setError(errorMsg);
      setAppState(AppState.ERROR);
    }
  };

  const handleImageSelect = useCallback((base64: string) => {
    setSelectedImage(base64);
    setIsCameraActive(false);
    performAnalysis(base64, currentLanguage);
  }, [currentLanguage]);

  const handleLearnMore = (query: string) => {
    setInitialEncyclopediaQuery(query);
    setAppState(AppState.ENCYCLOPEDIA);
  };

  const resetAnalysis = () => {
    setSelectedImage(null);
    setAnalysis(null);
    setAppState(AppState.IDLE);
    setIsCameraActive(false);
    setError(null);
    setEncyclopediaContent(null);
  };

  const handleLanguageChange = async (lang: Language) => {
    setCurrentLanguage(lang);
    
    // If we are currently looking at a result, re-run analysis in the new language
    if (appState === AppState.RESULT && selectedImage) {
      performAnalysis(selectedImage, lang);
    }

    // If we are currently looking at an encyclopedia entry, re-fetch it in the new language
    if (appState === AppState.ENCYCLOPEDIA && encyclopediaContent) {
      setAppState(AppState.ANALYZING);
      try {
        const result = await fetchEncyclopediaEntry(encyclopediaContent.scientificName || encyclopediaContent.title, lang);
        setEncyclopediaContent(result);
        setAppState(AppState.ENCYCLOPEDIA);
      } catch (err) {
        setAppState(AppState.ENCYCLOPEDIA);
      }
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <Header 
        currentLanguage={currentLanguage} 
        onLanguageChange={handleLanguageChange} 
        appState={appState}
        setAppState={setAppState}
        t={t}
      />
      
      <main className="flex-grow max-w-5xl mx-auto w-full px-4 sm:px-6 py-10">
        {appState === AppState.IDLE && !isCameraActive && (
          <div className="mb-10 text-center space-y-4 animate-in fade-in slide-in-from-top-4 duration-700">
            <h2 className="text-4xl sm:text-5xl font-extrabold text-gray-900 tracking-tight leading-tight">
              {t.intro_title_part1}<span className="text-emerald-600">{t.intro_title_part2}</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              {t.intro_description}
            </p>
          </div>
        )}

        <div className="relative">
          {appState === AppState.IDLE && !isCameraActive && (
            <ImageUploader 
              onImageSelect={handleImageSelect} 
              onCameraRequest={() => setIsCameraActive(true)}
              t={t}
            />
          )}

          {isCameraActive && (
            <LiveCamera 
              onCapture={handleImageSelect} 
              onCancel={() => setIsCameraActive(false)} 
            />
          )}

          {appState === AppState.ANALYZING && (
            <div className="bg-white rounded-[3rem] shadow-2xl border border-gray-100 p-12">
              <LoadingState t={t} />
            </div>
          )}

          {appState === AppState.RESULT && analysis && selectedImage && (
            <AnalysisResult 
              data={analysis} 
              imageUrl={selectedImage} 
              onReset={resetAnalysis} 
              onLearnMore={handleLearnMore}
              t={t}
            />
          )}

          {appState === AppState.ENCYCLOPEDIA && (
            <Encyclopedia 
              currentLanguage={currentLanguage} 
              t={t} 
              initialQuery={initialEncyclopediaQuery}
              setEncyclopediaContent={setEncyclopediaContent}
              encyclopediaContent={encyclopediaContent}
            />
          )}

          {appState === AppState.ERROR && (
            <div className="bg-white rounded-[3rem] shadow-2xl border border-rose-100 p-16 text-center max-w-2xl mx-auto animate-in zoom-in-95 duration-500">
              <div className="w-24 h-24 bg-rose-50 rounded-full flex items-center justify-center mx-auto mb-8 text-rose-500">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-3xl font-black text-slate-900 mb-4">{t.err_analysis_failed}</h3>
              <p className="text-slate-500 mb-10 text-lg leading-relaxed font-medium">{error}</p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <button 
                  onClick={resetAnalysis} 
                  className="w-full sm:w-auto px-12 py-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-[1.5rem] font-black shadow-xl shadow-emerald-100 transition-all active:scale-95"
                >
                  {t.btn_try_again}
                </button>
                <button 
                  onClick={() => setIsCameraActive(true)}
                  className="w-full sm:w-auto px-12 py-4 bg-white text-slate-700 border border-slate-200 rounded-[1.5rem] font-black hover:bg-slate-50 transition-all active:scale-95"
                >
                  {t.btn_open_camera}
                </button>
              </div>
            </div>
          )}
        </div>

        {appState === AppState.IDLE && !isCameraActive && (
          <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8 animate-in fade-in slide-in-from-bottom-8 duration-1000">
            <div className="bg-white p-10 rounded-[2.5rem] border border-gray-100 shadow-sm hover:shadow-xl transition-all hover:-translate-y-1">
              <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center mb-6 text-emerald-600">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h4 className="font-black text-slate-900 mb-3 text-xl">{t.feature_instant_title}</h4>
              <p className="text-sm text-slate-500 leading-relaxed font-medium">{t.feature_instant_desc}</p>
            </div>
            <div className="bg-white p-10 rounded-[2.5rem] border border-gray-100 shadow-sm hover:shadow-xl transition-all hover:-translate-y-1">
              <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center mb-6 text-blue-600">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h4 className="font-black text-slate-900 mb-3 text-xl">{t.feature_accuracy_title}</h4>
              <p className="text-sm text-slate-500 leading-relaxed font-medium">{t.feature_accuracy_desc}</p>
            </div>
            <div className="bg-white p-10 rounded-[2.5rem] border border-gray-100 shadow-sm hover:shadow-xl transition-all hover:-translate-y-1">
              <div className="w-12 h-12 bg-amber-50 rounded-2xl flex items-center justify-center mb-6 text-amber-600">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                </svg>
              </div>
              <h4 className="font-black text-slate-900 mb-3 text-xl">{t.feature_expert_title}</h4>
              <p className="text-sm text-slate-500 leading-relaxed font-medium">{t.feature_expert_desc}</p>
            </div>
          </div>
        )}
      </main>

      <footer className="bg-white border-t border-gray-200 py-12 mt-auto">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-xs text-slate-400 font-bold tracking-[0.2em] uppercase">{t.footer_text}</p>
        </div>
      </footer>

      <FloatingAssistant 
        currentLanguage={currentLanguage} 
        t={t} 
        appState={appState}
        analysisData={analysis}
        encyclopediaData={encyclopediaContent}
      />
    </div>
  );
};

export default App;

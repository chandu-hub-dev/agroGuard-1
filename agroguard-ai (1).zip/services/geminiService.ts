
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { PlantAnalysis, Language, EncyclopediaEntry } from "../types";

// Always use a new instance to ensure the latest API key is used
const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY as string });

/**
 * Compresses and resizes the image before sending to Gemini.
 * This drastically reduces upload time and latency.
 */
async function optimizeImage(base64Str: string, maxWidth = 1024): Promise<string> {
  return new Promise((resolve) => {
    const img = new Image();
    img.src = base64Str;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;

      if (width > maxWidth) {
        height = Math.round((height * maxWidth) / width);
        width = maxWidth;
      }

      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(img, 0, 0, width, height);
      resolve(canvas.toDataURL('image/jpeg', 0.85)); // 85% quality is optimal for vision AI
    };
  });
}

const extractJSON = (text: string): string => {
  try {
    const firstOpen = text.indexOf('{');
    const lastClose = text.lastIndexOf('}');
    if (firstOpen === -1 || lastClose === -1) return text;
    return text.substring(firstOpen, lastClose + 1);
  } catch (e) {
    return text;
  }
};

export const analyzePlantImage = async (base64Image: string, language: Language = 'en'): Promise<PlantAnalysis> => {
  const ai = getAI();
  const modelName = 'gemini-3-flash-preview';
  
  // Optimize payload size
  const compressedImage = await optimizeImage(base64Image);
  
  const systemInstruction = `You are a world-class plant pathologist.
  Task: Identify plant species and diagnose diseases from images.
  Consistency: Provide all textual values in strictly ${language}.
  Formatting: Return ONLY valid JSON. No conversational filler.
  Precision: High. If symptoms are ambiguous, provide the most probable diagnosis based on visual patterns.`;

  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/jpeg',
              data: compressedImage.split(',')[1],
            },
          },
          { text: `Diagnose this plant leaf. Language: ${language}.` },
        ],
      },
      config: {
        systemInstruction,
        temperature: 0.1, // Low temperature for higher accuracy and consistency
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            plantName: { type: Type.STRING },
            isHealthy: { type: Type.BOOLEAN },
            diseaseName: { type: Type.STRING, nullable: true },
            confidence: { type: Type.NUMBER },
            symptoms: { type: Type.ARRAY, items: { type: Type.STRING } },
            recommendations: { type: Type.ARRAY, items: { type: Type.STRING } },
            urgency: { type: Type.STRING, enum: ['low', 'medium', 'high'] }
          },
          required: ["plantName", "isHealthy", "diseaseName", "confidence", "symptoms", "recommendations", "urgency"]
        }
      },
    });

    return JSON.parse(extractJSON(response.text || "{}")) as PlantAnalysis;
  } catch (error: any) {
    console.error("Analysis Error:", error);
    throw new Error("Unable to analyze leaf. Please ensure the photo is clear and well-lit.");
  }
};

export const fetchEncyclopediaEntry = async (query: string, language: Language = 'en'): Promise<EncyclopediaEntry> => {
  const ai = getAI();
  const modelName = 'gemini-3-flash-preview';
  
  const systemInstruction = `You are an expert botanical database. Provide technical but accessible reports in ${language}.`;

  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: `Report for: ${query}`,
      config: {
        systemInstruction,
        temperature: 0.1,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            scientificName: { type: Type.STRING },
            category: { type: Type.STRING },
            description: { type: Type.STRING },
            causes: { type: Type.ARRAY, items: { type: Type.STRING } },
            detailedTreatments: { type: Type.ARRAY, items: { type: Type.STRING } },
            preventionMeasures: { type: Type.ARRAY, items: { type: Type.STRING } },
            culturalPractices: { type: Type.ARRAY, items: { type: Type.STRING } },
          },
          required: ["title", "scientificName", "category", "description", "causes", "detailedTreatments", "preventionMeasures", "culturalPractices"]
        }
      }
    });

    return JSON.parse(extractJSON(response.text || "{}")) as EncyclopediaEntry;
  } catch (error) {
    console.error("Encyclopedia Error:", error);
    throw error;
  }
};

export const generateSpeech = async (text: string, language: Language = 'en'): Promise<string | undefined> => {
  const ai = getAI();
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: `Speak this strictly in ${language}: ${text}` }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' },
          },
        },
      },
    });
    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  } catch (error) {
    return undefined;
  }
};

export function decodeBase64(base64: string) {
  const binaryString = atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
  return bytes;
}

export async function decodeAudioData(data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer, data.byteOffset, data.byteLength / 2);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}
